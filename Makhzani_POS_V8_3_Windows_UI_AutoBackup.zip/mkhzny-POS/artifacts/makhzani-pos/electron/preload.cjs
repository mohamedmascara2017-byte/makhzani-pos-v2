const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('makhzaniDesktop', {
  isDesktop: true,
  platform: process.platform,
  getBackupFolder: () => ipcRenderer.invoke('makhzani:backup:get-folder'),
  chooseBackupFolder: () => ipcRenderer.invoke('makhzani:backup:choose-folder'),
  saveAutomaticBackup: (json) => ipcRenderer.invoke('makhzani:backup:save', json),
});
