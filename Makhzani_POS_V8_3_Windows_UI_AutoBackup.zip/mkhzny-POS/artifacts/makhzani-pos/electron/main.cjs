const { app, BrowserWindow, session, shell, ipcMain, dialog } = require('electron');
const path = require('node:path');
const fs = require('node:fs');
const http = require('node:http');


// Optional automatic backup folder. Select the Google Drive for desktop folder
// (or any folder that is synchronized by a trusted cloud-drive client).
const BACKUP_CONFIG_FILE = () => path.join(app.getPath('userData'), 'backup-folder.json');

function readBackupFolder() {
  try {
    const value = JSON.parse(fs.readFileSync(BACKUP_CONFIG_FILE(), 'utf8'));
    return typeof value.folder === 'string' && fs.existsSync(value.folder) ? value.folder : null;
  } catch {
    return null;
  }
}

function registerBackupIpc() {
  ipcMain.handle('makhzani:backup:get-folder', async () => ({ folder: readBackupFolder() }));

  ipcMain.handle('makhzani:backup:choose-folder', async (event) => {
    const result = await dialog.showOpenDialog(BrowserWindow.fromWebContents(event.sender), {
      title: 'اختر مجلد النسخ الاحتياطي (يمكن اختيار مجلد Google Drive)',
      properties: ['openDirectory', 'createDirectory'],
    });
    if (result.canceled || !result.filePaths[0]) return { folder: null, canceled: true };
    const folder = result.filePaths[0];
    fs.mkdirSync(folder, { recursive: true });
    fs.writeFileSync(BACKUP_CONFIG_FILE(), JSON.stringify({ folder, updatedAt: new Date().toISOString() }, null, 2), 'utf8');
    return { folder, canceled: false };
  });

  ipcMain.handle('makhzani:backup:save', async (_event, rawJson) => {
    const folder = readBackupFolder();
    if (!folder) return { saved: false, reason: 'folder-not-selected' };
    if (typeof rawJson !== 'string' || rawJson.length > 100 * 1024 * 1024) {
      throw new Error('بيانات النسخة الاحتياطية غير صالحة أو كبيرة جداً.');
    }
    let parsed;
    try { parsed = JSON.parse(rawJson); } catch { throw new Error('تعذر قراءة بيانات النسخة الاحتياطية.'); }
    if (!parsed || parsed.format !== 'makhzani-pos-backup-v1' || !Array.isArray(parsed.products) || !Array.isArray(parsed.sales)) {
      throw new Error('صيغة النسخة الاحتياطية غير معروفة.');
    }

    const latest = path.join(folder, 'makhzani-auto-backup-latest.json');
    const dayFile = path.join(folder, `makhzani-auto-backup-${new Date().toISOString().slice(0, 10)}.json`);
    const temp = `${latest}.tmp`;
    fs.writeFileSync(temp, JSON.stringify(parsed, null, 2), 'utf8');
    fs.renameSync(temp, latest);
    fs.writeFileSync(dayFile, JSON.stringify(parsed, null, 2), 'utf8');

    // Keep the latest file plus 30 dated snapshots to avoid filling the drive.
    const dated = fs.readdirSync(folder)
      .filter((name) => /^makhzani-auto-backup-\d{4}-\d{2}-\d{2}\.json$/.test(name))
      .sort()
      .reverse();
    for (const oldName of dated.slice(30)) {
      try { fs.unlinkSync(path.join(folder, oldName)); } catch {}
    }
    return { saved: true, file: latest, savedAt: new Date().toISOString() };
  });
}

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.webmanifest': 'application/manifest+json',
};

function startStaticServer(port = DESKTOP_PORT) {
  const distDir = path.resolve(__dirname, '..', 'dist');
  const indexFile = path.join(distDir, 'index.html');
  if (!fs.existsSync(indexFile)) {
    throw new Error(`The exported app was not found: ${indexFile}`);
  }

  const server = http.createServer((req, res) => {
    let pathname;
    try {
      pathname = decodeURIComponent(new URL(req.url, 'http://127.0.0.1').pathname);
    } catch {
      res.writeHead(400).end('Bad request');
      return;
    }

    const relativePath = pathname.replace(/^\/+/, '');
    let filePath = path.resolve(distDir, relativePath || 'index.html');
    if (filePath !== distDir && !filePath.startsWith(distDir + path.sep)) {
      res.writeHead(403).end('Forbidden');
      return;
    }

    try {
      if (fs.existsSync(filePath) && fs.statSync(filePath).isDirectory()) {
        filePath = path.join(filePath, 'index.html');
      }
      if (!fs.existsSync(filePath) || !fs.statSync(filePath).isFile()) {
        filePath = indexFile;
      }
      const contentType = MIME_TYPES[path.extname(filePath).toLowerCase()] || 'application/octet-stream';
      res.writeHead(200, {
        'Content-Type': contentType,
        'Cache-Control': path.basename(filePath) === 'index.html' ? 'no-cache' : 'public, max-age=31536000, immutable',
        'X-Content-Type-Options': 'nosniff',
      });
      fs.createReadStream(filePath).pipe(res);
    } catch (error) {
      console.error('Static file server error:', error);
      if (!res.headersSent) res.writeHead(500);
      res.end('Unable to load the application file.');
    }
  });

  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(port, '127.0.0.1', () => {
      server.removeListener('error', reject);
      const address = server.address();
      resolve({ server, url: `http://127.0.0.1:${address.port}` });
    });
  });
}

function createWindow(appUrl) {
  const win = new BrowserWindow({
    width: 1440,
    height: 920,
    minWidth: 1050,
    minHeight: 700,
    show: false,
    autoHideMenuBar: true,
    backgroundColor: '#f7f8fa',
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });

  win.once('ready-to-show', () => win.show());
  win.webContents.on('did-fail-load', (_event, code, description, validatedURL) => {
    console.error('Makhzani page failed to load:', code, description, validatedURL);
  });
  win.webContents.on('console-message', (_event, details) => {
    if (details.level >= 2) console.error('Makhzani renderer:', details.message);
  });
  win.loadURL(appUrl);
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('https://') || url.startsWith('http://')) shell.openExternal(url);
    return { action: 'deny' };
  });
  return win;
}

let staticServer;
const DESKTOP_PORT = 32145;
const gotSingleInstanceLock = app.requestSingleInstanceLock();
if (!gotSingleInstanceLock) app.quit();

app.whenReady().then(async () => {
  if (!gotSingleInstanceLock) return;
  registerBackupIpc();
  // Allow Chromium's camera permission flow for Expo Camera / barcode scanning.
  session.defaultSession.setPermissionRequestHandler((_webContents, permission, callback) => {
    callback(permission === 'media' || permission === 'camera' || permission === 'videoCapture');
  });
  session.defaultSession.setPermissionCheckHandler((_webContents, permission) => {
    return permission === 'media' || permission === 'camera' || permission === 'videoCapture';
  });
  if (typeof session.defaultSession.setDevicePermissionHandler === 'function') {
    session.defaultSession.setDevicePermissionHandler((details) => {
      return details.deviceType === 'videoinput';
    });
  }

  try {
    const hostedApp = await startStaticServer(DESKTOP_PORT);
    staticServer = hostedApp.server;
    createWindow(hostedApp.url);
  } catch (error) {
    console.error('Unable to start Makhzani POS:', error);
    app.quit();
  }

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0 && staticServer) {
      const address = staticServer.address();
      createWindow(`http://127.0.0.1:${address.port}`);
    }
  });
});

app.on('second-instance', () => {
  const win = BrowserWindow.getAllWindows()[0];
  if (win) { if (win.isMinimized()) win.restore(); win.focus(); }
});

app.on('before-quit', () => {
  if (staticServer) staticServer.close();
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
