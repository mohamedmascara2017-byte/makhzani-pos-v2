/**
 * Makhzani POS — refreshed retail interface palette.
 * Emerald actions, deep slate typography, and calm neutral surfaces.
 */
const colors = {
  light: {
    text: '#172B2A',
    tint: '#087F68',
    background: '#F3F7F6',
    foreground: '#172B2A',
    card: '#FFFFFF',
    cardForeground: '#172B2A',
    primary: '#087F68',
    primaryForeground: '#FFFFFF',
    secondary: '#E1F2ED',
    secondaryForeground: '#075B4B',
    muted: '#EAF0EE',
    mutedForeground: '#667875',
    accent: '#F4B544',
    accentForeground: '#49300A',
    destructive: '#D84C58',
    destructiveForeground: '#FFFFFF',
    border: '#DCE7E3',
    input: '#CBDAD5',
  },
  dark: {
    text: '#F0F7F4',
    tint: '#53C7A7',
    background: '#101B1A',
    foreground: '#F0F7F4',
    card: '#192725',
    cardForeground: '#F0F7F4',
    primary: '#53C7A7',
    primaryForeground: '#09241D',
    secondary: '#24423A',
    secondaryForeground: '#C6F0E2',
    muted: '#21312E',
    mutedForeground: '#A2B8B0',
    accent: '#F4C46E',
    accentForeground: '#49300A',
    destructive: '#F0747D',
    destructiveForeground: '#FFFFFF',
    border: '#30433E',
    input: '#405750',
  },
  radius: 18,
};
export default colors;
