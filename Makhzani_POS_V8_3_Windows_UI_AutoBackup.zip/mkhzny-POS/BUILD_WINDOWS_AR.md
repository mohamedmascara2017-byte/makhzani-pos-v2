# مخزني V6 — إعداد بناء Windows

هذه النسخة مبنية على مشروع V5 المرسل، مع إضافة Workflow صحيح لـ GitHub Actions.

## سبب أخطاء البناء السابقة

المشروع ليس في جذر المستودع؛ جذر مساحة العمل الحقيقي هو `mkhzny-POS/`. لذلك يجب تنفيذ `pnpm install` وأمر البناء من هذا المجلد. كما أن ملف القفل موجود في `mkhzny-POS/pnpm-lock.yaml`.

## البناء

يوجد ملف GitHub Actions في:

`.github/workflows/build-windows.yml`

بعد رفع محتويات هذه الحزمة إلى المستودع (مع الحفاظ على مجلد `mkhzny-POS`)، افتح Actions وشغّل `Build Makhzani POS for Windows`.

ملف التثبيت المتوقع:

`mkhzny-POS/artifacts/makhzani-pos/release/*.exe`

ملاحظة: إعداد Workflow ومسارات البناء تم ضبطها حسب الملفات الموجودة في الأرشيف. لا يعني ذلك أن بناء Windows تم اختباره على GitHub بعد؛ يجب تشغيل Workflow للتحقق من الاعتماديات ونجاح التصدير.
