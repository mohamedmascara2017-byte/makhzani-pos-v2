import React, { useState } from 'react';
import { Alert, Modal, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { Feather } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { AppButton, PageHeader, TextField } from '@/components/common';
import { ProductInput, useStore } from '@/components/StoreContext';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

export default function ProductFormScreen() {
  const colors = useColors();
  const { id } = useLocalSearchParams<{ id?: string }>();
  const { products, addOrUpdateProduct } = useStore();
  const [cameraVisible, setCameraVisible] = useState(false);
  const [cameraPermission, requestCameraPermission] = useCameraPermissions();
  const [barcodeScanned, setBarcodeScanned] = useState(false);

  const openBarcodeScanner = async () => {
    if (!cameraPermission?.granted) {
      const result = await requestCameraPermission();
      if (!result.granted) {
        Alert.alert('إذن الكاميرا مطلوب', 'اسمح للتطبيق باستخدام الكاميرا لمسح الباركود، أو اكتب الرمز يدويًا.');
        return;
      }
    }
    setBarcodeScanned(false);
    setCameraVisible(true);
  };

  const handleBarcodeScanned = ({ data }: { data: string }) => {
    if (barcodeScanned || !data) return;
    setBarcodeScanned(true);
    setForm((old) => ({ ...old, barcode: data.trim() }));
    setCameraVisible(false);
    Alert.alert('تم مسح الباركود', `الرمز: ${data.trim()}`);
  };
  const existing = products.find((product) => product.id === id);
  const [form, setForm] = useState<ProductInput>(() => existing ? {
    ...existing,
    alternateBarcodes: [...existing.alternateBarcodes],
  } : {
    name: '',
    barcode: '',
    alternateBarcodes: [],
    purchasePrice: 0,
    salePrice: 0,
    quantity: 0,
    minQuantity: 0,
    unit: 'قطعة',
    category: '',
    supplier: '',
  });
  const setText = (key: keyof ProductInput, value: string) => setForm((old) => ({
    ...old,
    [key]: value,
  }));
  const setNumber = (key: 'purchasePrice' | 'salePrice' | 'quantity' | 'minQuantity', value: string) => {
    const number = Number(value.replace(',', '.'));
    setForm((old) => ({ ...old, [key]: Number.isFinite(number) ? number : 0 }));
  };
  const save = () => {
    try {
      if (form.salePrice < 0 || form.purchasePrice < 0 || form.quantity < 0 || form.minQuantity < 0) {
        throw new Error('لا يمكن إدخال قيمة سالبة.');
      }
      addOrUpdateProduct(form);
      router.back();
    } catch (error) {
      Alert.alert('تعذر حفظ المنتج', error instanceof Error ? error.message : 'راجع البيانات وحاول مرة أخرى.');
    }
  };

  return (
    <SafeAreaView edges={['top', 'left', 'right']} style={{ flex: 1, backgroundColor: colors.background, paddingTop: Platform.OS === 'web' ? 67 : 0, paddingBottom: Platform.OS === 'web' ? 34 : 0 }}>
      <KeyboardAwareScrollViewCompat contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled" bottomOffset={70}>
        <PageHeader title={existing ? 'تعديل المنتج' : 'منتج جديد'} subtitle="بيانات المنتج والأسعار والكميات" onBack={() => router.back()} />
        <Text style={[styles.section, { color: colors.foreground }]}>التعريف</Text>
        <TextField label="اسم المنتج *" value={form.name} onChangeText={(value) => setText('name', value)} placeholder="مثال: زيت زيتون 1 لتر" autoCapitalize="sentences" testID="product-name" />
        <TextField label="الباركود" value={form.barcode} onChangeText={(value) => setText('barcode', value)} placeholder="امسح الرمز أو اكتبه" />
        <Pressable onPress={openBarcodeScanner} style={[styles.scanButton, { borderColor: colors.primary, backgroundColor: colors.card }]} accessibilityRole="button" accessibilityLabel="مسح الباركود بالكاميرا">
          <Feather name="camera" size={18} color={colors.primary} />
          <Text style={[styles.scanButtonText, { color: colors.primary }]}>مسح الباركود بالكاميرا</Text>
        </Pressable>
        <TextField label="رموز إضافية (افصل بينها بفاصلة)" value={form.alternateBarcodes.join(', ')} onChangeText={(value) => setForm((old) => ({ ...old, alternateBarcodes: value.split(',').map((part) => part.trim()).filter(Boolean) }))} placeholder="اختياري" />
        <TextField label="التصنيف" value={form.category} onChangeText={(value) => setText('category', value)} placeholder="مواد غذائية" />
        <Text style={[styles.section, { color: colors.foreground }]}>الأسعار والمخزون</Text>
        <TextField label="سعر البيع (دج)" value={`${form.salePrice}`} onChangeText={(value) => setNumber('salePrice', value)} keyboardType="decimal-pad" />
        <TextField label="سعر الشراء (دج)" value={`${form.purchasePrice}`} onChangeText={(value) => setNumber('purchasePrice', value)} keyboardType="decimal-pad" />
        <TextField label="الكمية الحالية" value={`${form.quantity}`} onChangeText={(value) => setNumber('quantity', value)} keyboardType="decimal-pad" />
        <TextField label="حد التنبيه للمخزون" value={`${form.minQuantity}`} onChangeText={(value) => setNumber('minQuantity', value)} keyboardType="decimal-pad" />
        <TextField label="وحدة البيع" value={form.unit} onChangeText={(value) => setText('unit', value)} placeholder="قطعة، كيلو..." />
        <TextField label="المورد المعتاد" value={form.supplier} onChangeText={(value) => setText('supplier', value)} placeholder="اختياري" />
        <AppButton title={existing ? 'حفظ التعديلات' : 'إضافة المنتج'} icon="check" onPress={save} testID="save-product" />
      </KeyboardAwareScrollViewCompat>
      <Modal visible={cameraVisible} animationType="slide" onRequestClose={() => setCameraVisible(false)}>
        <View style={styles.cameraContainer}>
          <CameraView
            style={StyleSheet.absoluteFillObject}
            facing="back"
            barcodeScannerSettings={{ barcodeTypes: ['ean13', 'ean8', 'upc_a', 'upc_e', 'code128', 'code39', 'qr', 'itf', 'pdf417', 'datamatrix'] }}
            onBarcodeScanned={barcodeScanned ? undefined : handleBarcodeScanned}
          />
          <View style={styles.cameraTop}>
            <Pressable onPress={() => setCameraVisible(false)} style={styles.closeCamera} accessibilityRole="button" accessibilityLabel="إغلاق الكاميرا">
              <Feather name="x" size={24} color="#FFFFFF" />
            </Pressable>
            <Text style={styles.cameraTitle}>وجّه الكاميرا نحو الباركود</Text>
          </View>
          <View pointerEvents="none" style={styles.scanOverlay}>
            <View style={styles.scanFrame} />
            <Text style={styles.scanHint}>ثبّت الرمز داخل الإطار</Text>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 20, paddingTop: 12, paddingBottom: 35, gap: 14 },
  section: { marginTop: 7, fontSize: 16, fontWeight: '700', textAlign: 'right', writingDirection: 'rtl' },
  scanButton: { minHeight: 46, borderWidth: 1, borderRadius: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 9, marginTop: -6 },
  scanButtonText: { fontSize: 14, fontWeight: '700', writingDirection: 'rtl' },
  cameraContainer: { flex: 1, backgroundColor: '#000000', justifyContent: 'space-between' },
  cameraTop: { paddingTop: 55, paddingHorizontal: 18, flexDirection: 'row', alignItems: 'center', gap: 16, backgroundColor: 'rgba(0,0,0,0.35)' },
  closeCamera: { width: 44, height: 44, borderRadius: 22, backgroundColor: 'rgba(0,0,0,0.45)', alignItems: 'center', justifyContent: 'center' },
  cameraTitle: { flex: 1, color: '#FFFFFF', fontSize: 16, fontWeight: '700', textAlign: 'right', writingDirection: 'rtl' },
  scanOverlay: { alignItems: 'center', justifyContent: 'center', paddingBottom: 90, gap: 18 },
  scanFrame: { width: '78%', height: 150, borderWidth: 3, borderColor: '#35D07F', borderRadius: 16, backgroundColor: 'transparent' },
  scanHint: { color: '#FFFFFF', fontSize: 14, fontWeight: '600', backgroundColor: 'rgba(0,0,0,0.45)', paddingHorizontal: 14, paddingVertical: 8, borderRadius: 10, writingDirection: 'rtl' },
});
