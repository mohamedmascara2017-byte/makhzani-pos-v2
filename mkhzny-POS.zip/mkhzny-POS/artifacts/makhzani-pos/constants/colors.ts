/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    text: '#17281F',
    tint: '#176B43',
    background: '#F4F7F2',
    foreground: '#17281F',
    card: '#FFFFFF',
    cardForeground: '#17281F',
    primary: '#176B43',
    primaryForeground: '#FFFFFF',
    secondary: '#E5EEE7',
    secondaryForeground: '#28543B',
    muted: '#EEF2ED',
    mutedForeground: '#718075',
    accent: '#F5B84B',
    accentForeground: '#382807',
    destructive: '#C74646',
    destructiveForeground: '#FFFFFF',
    border: '#E1E8E0',
    input: '#DAE3DA',
  },
  dark: {
    text: '#EDF4EE',
    tint: '#73C99A',
    background: '#111A14',
    foreground: '#EDF4EE',
    card: '#1A261E',
    cardForeground: '#EDF4EE',
    primary: '#73C99A',
    primaryForeground: '#102017',
    secondary: '#25372A',
    secondaryForeground: '#D2E8D8',
    muted: '#253129',
    mutedForeground: '#A2B2A5',
    accent: '#F5B84B',
    accentForeground: '#382807',
    destructive: '#E56D6D',
    destructiveForeground: '#FFFFFF',
    border: '#304035',
    input: '#3A4A3D',
  },
  radius: 18,
};

export default colors;
