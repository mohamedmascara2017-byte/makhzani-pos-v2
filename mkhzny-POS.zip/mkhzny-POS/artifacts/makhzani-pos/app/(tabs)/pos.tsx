import React, { useMemo, useRef, useState } from 'react';
import { Alert, FlatList, Keyboard, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { Feather } from '@expo/vector-icons';
import { AppButton, AppPage, Card, formatMoney, TextField } from '@/components/common';
import { Product, useStore } from '@/components/StoreContext';
import { useColors } from '@/hooks/useColors';

export default function PosScreen() {
  const colors = useColors();
  const { products, completeSale } = useStore();
  const [query, setQuery] = useState('');
  const [cart, setCart] = useState<Record<string, number>>({});
  const [discountText, setDiscountText] = useState('0');
  const [paymentMethod, setPaymentMethod] = useState('نقدي');
  const [scanning, setScanning] = useState(false);
  const [permission, requestPermission] = useCameraPermissions();
  const [submitting, setSubmitting] = useState(false);
  const scannedOnce = useRef(false);

  const selected = useMemo(
    () => Object.entries(cart).map(([productId, quantity]) => ({
      product: products.find((item) => item.id === productId),
      quantity,
    })).filter((item): item is { product: Product; quantity: number } => !!item.product),
    [cart, products],
  );
  const subtotal = selected.reduce((sum, item) => sum + item.product.salePrice * item.quantity, 0);
  const discount = Number(discountText.replace(',', '.')) || 0;
  const total = Math.max(0, subtotal - discount);
  const matches = useMemo(() => {
    const q = query.trim().toLocaleLowerCase();
    if (!q) return [];
    return products.filter((product) => product.name.toLocaleLowerCase().includes(q) || product.barcode.includes(q) || product.alternateBarcodes.some((code) => code.includes(q))).slice(0, 6);
  }, [products, query]);

  const addProduct = (product: Product) => {
    setCart((old) => {
      const next = (old[product.id] ?? 0) + 1;
      if (next > product.quantity) {
        Alert.alert('المخزون غير كافٍ', `المتاح من ${product.name}: ${product.quantity} ${product.unit}`);
        return old;
      }
      return { ...old, [product.id]: next };
    });
    setQuery('');
    Keyboard.dismiss();
  };
  const addByCode = (code: string) => {
    const match = products.find((product) => product.barcode === code || product.alternateBarcodes.includes(code));
    if (match) addProduct(match);
    else if (code.trim()) Alert.alert('لم يتم العثور على المنتج', 'تحقق من الباركود أو أضف المنتج إلى المخزون.');
    setQuery('');
    setScanning(false);
  };
  const finish = () => {
    if (!selected.length || submitting) return;
    setSubmitting(true);
    try {
      const sale = completeSale(selected.map(({ product, quantity }) => ({ productId: product.id, quantity })), discount, paymentMethod);
      setCart({});
      setDiscountText('0');
      Alert.alert('تم حفظ البيع', `رقم الفاتورة ${sale.id.slice(-6)}\nالإجمالي: ${formatMoney(sale.total)}`);
    } catch (error) {
      Alert.alert('تعذر إتمام البيع', error instanceof Error ? error.message : 'حاول مرة أخرى.');
    } finally {
      setSubmitting(false);
    }
  };
  const openCamera = async () => {
    if (!permission?.granted) {
      const result = await requestPermission();
      if (!result.granted) {
        Alert.alert('إذن الكاميرا مطلوب', 'فعّل إذن الكاميرا لإضافة المنتجات بمسح الباركود.');
        return;
      }
    }
    scannedOnce.current = false;
    setScanning(true);
  };

  return (
    <AppPage scroll={false}>
      <View style={styles.container}>
        <View style={styles.titleRow}>
          <View style={{ flex: 1 }}>
            <Text style={[styles.heading, { color: colors.foreground }]}>نقطة البيع</Text>
            <Text style={[styles.subheading, { color: colors.mutedForeground }]}>أضف المنتجات وأكمل الفاتورة</Text>
          </View>
          <Pressable accessibilityLabel="مسح باركود" onPress={scanning ? () => setScanning(false) : openCamera} style={[styles.scanButton, { backgroundColor: scanning ? colors.destructive : colors.primary }]}>
            <Feather name={scanning ? 'x' : 'maximize'} size={18} color="#FFFFFF" />
            <Text style={styles.scanButtonText}>{scanning ? 'إغلاق' : 'مسح'}</Text>
          </Pressable>
        </View>
        {scanning && permission?.granted ? (
          <View style={styles.cameraFrame}>
            <CameraView
              style={StyleSheet.absoluteFill}
              facing="back"
              barcodeScannerSettings={{ barcodeTypes: ['ean13', 'ean8', 'upc_a', 'upc_e', 'code128', 'code39', 'qr'] }}
              onBarcodeScanned={({ data }) => {
                if (scannedOnce.current) return;
                scannedOnce.current = true;
                addByCode(data);
              }}
            />
            <View pointerEvents="none" style={styles.scanFrame}><View style={styles.scanLine} /></View>
            <Text style={styles.cameraHint}>وجّه الكاميرا نحو باركود المنتج</Text>
          </View>
        ) : null}
        <View style={styles.searchRow}>
          <View style={{ flex: 1 }}>
            <TextField
              label=""
              value={query}
              onChangeText={setQuery}
              onSubmitEditing={() => addByCode(query.trim())}
              placeholder="ابحث بالاسم أو أدخل الباركود"
              returnKeyType="search"
              testID="pos-search"
              style={{ minHeight: 45 }}
            />
          </View>
          <Pressable accessibilityLabel="إضافة بالباركود" onPress={() => addByCode(query.trim())} style={[styles.searchButton, { backgroundColor: colors.secondary }]}>
            <Feather name="search" size={19} color={colors.primary} />
          </Pressable>
        </View>
        {matches.length ? (
          <Card style={styles.results}>
            {matches.map((product) => (
              <Pressable key={product.id} onPress={() => addProduct(product)} style={[styles.resultRow, { borderBottomColor: colors.border }]}>
                <View style={{ flex: 1, alignItems: 'flex-start' }}>
                  <Text style={[styles.productName, { color: colors.foreground }]}>{product.name}</Text>
                  <Text style={[styles.productMeta, { color: colors.mutedForeground }]}>{formatMoney(product.salePrice)} · المتوفر {product.quantity}</Text>
                </View>
                <Feather name="plus-circle" size={21} color={colors.primary} />
              </Pressable>
            ))}
          </Card>
        ) : null}
        <View style={styles.cartHeader}>
          <Text style={[styles.cartTitle, { color: colors.foreground }]}>السلة</Text>
          <Text style={[styles.cartCount, { color: colors.mutedForeground }]}>{selected.length} أصناف</Text>
        </View>
        <FlatList
          data={selected}
          keyExtractor={(item) => item.product.id}
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={selected.length ? styles.cartList : styles.cartEmpty}
          ListEmptyComponent={
            <View style={styles.emptyCart}>
              <View style={[styles.emptyCartIcon, { backgroundColor: colors.secondary }]}><Feather name="shopping-cart" size={22} color={colors.primary} /></View>
              <Text style={[styles.emptyTitle, { color: colors.foreground }]}>السلة فارغة</Text>
              <Text style={[styles.emptyNote, { color: colors.mutedForeground }]}>امسح باركودًا أو ابحث عن منتج لإضافته.</Text>
            </View>
          }
          renderItem={({ item }) => (
            <View style={[styles.cartItem, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <View style={{ flex: 1, alignItems: 'flex-start' }}>
                <Text style={[styles.productName, { color: colors.foreground }]}>{item.product.name}</Text>
                <Text style={[styles.productMeta, { color: colors.mutedForeground }]}>{formatMoney(item.product.salePrice)} × {item.quantity} {item.product.unit}</Text>
              </View>
              <Text style={[styles.lineTotal, { color: colors.foreground }]}>{formatMoney(item.product.salePrice * item.quantity)}</Text>
              <Pressable accessibilityLabel="حذف من السلة" onPress={() => setCart((old) => { const next = { ...old }; delete next[item.product.id]; return next; })} style={styles.removeButton}>
                <Feather name="trash-2" size={16} color={colors.destructive} />
              </Pressable>
              <View style={styles.stepper}>
                <Pressable accessibilityLabel="زيادة الكمية" onPress={() => addProduct(item.product)} style={[styles.stepButton, { backgroundColor: colors.secondary }]}><Feather name="plus" size={14} color={colors.primary} /></Pressable>
                <Text style={[styles.quantity, { color: colors.foreground }]}>{item.quantity}</Text>
                <Pressable accessibilityLabel="تقليل الكمية" onPress={() => setCart((old) => {
                  const quantity = (old[item.product.id] ?? 0) - 1;
                  if (quantity <= 0) { const next = { ...old }; delete next[item.product.id]; return next; }
                  return { ...old, [item.product.id]: quantity };
                })} style={[styles.stepButton, { backgroundColor: colors.secondary }]}><Feather name="minus" size={14} color={colors.primary} /></Pressable>
              </View>
            </View>
          )}
        />
        <Card style={styles.footer}>
          <View style={styles.payRow}>
            <Text style={[styles.payLabel, { color: colors.mutedForeground }]}>طريقة الدفع</Text>
            <View style={styles.paymentOptions}>
              {['نقدي', 'بطاقة'].map((method) => (
                <Pressable key={method} onPress={() => setPaymentMethod(method)} style={[styles.paymentOption, { backgroundColor: paymentMethod === method ? colors.primary : colors.secondary }]}>
                  <Text style={{ color: paymentMethod === method ? colors.primaryForeground : colors.secondaryForeground, fontSize: 12, fontWeight: '700' }}>{method}</Text>
                </Pressable>
              ))}
            </View>
          </View>
          <View style={styles.totalRow}><Text style={[styles.totalLabel, { color: colors.mutedForeground }]}>المجموع</Text><Text style={[styles.totalValue, { color: colors.foreground }]}>{formatMoney(subtotal)}</Text></View>
          <View style={styles.discountRow}>
            <TextField label="الخصم" value={discountText} onChangeText={setDiscountText} keyboardType="decimal-pad" placeholder="0" style={{ minHeight: 40, width: 100, textAlign: 'right' }} />
            <View style={styles.totalRight}><Text style={[styles.totalLabel, { color: colors.mutedForeground }]}>الإجمالي</Text><Text style={[styles.grandTotal, { color: colors.primary }]}>{formatMoney(total)}</Text></View>
          </View>
          <AppButton title="إتمام البيع" icon="check" onPress={finish} disabled={!selected.length || discount > subtotal} loading={submitting} testID="complete-sale" />
        </Card>
      </View>
    </AppPage>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, paddingBottom: 6, gap: 12 },
  titleRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  heading: { fontSize: 24, fontWeight: '700', textAlign: 'right', writingDirection: 'rtl' },
  subheading: { marginTop: 3, fontSize: 12, textAlign: 'right', writingDirection: 'rtl' },
  scanButton: { height: 40, minWidth: 76, paddingHorizontal: 12, borderRadius: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6 },
  scanButtonText: { color: '#FFFFFF', fontSize: 12, fontWeight: '700' },
  cameraFrame: { height: 180, borderRadius: 20, overflow: 'hidden', backgroundColor: '#101713', alignItems: 'center', justifyContent: 'center' },
  scanFrame: { width: 210, height: 92, borderWidth: 2, borderColor: '#E8F5EC', borderRadius: 14, justifyContent: 'center', overflow: 'hidden' },
  scanLine: { height: 2, backgroundColor: '#F5B84B', marginHorizontal: 5 },
  cameraHint: { color: '#FFFFFF', backgroundColor: 'rgba(0,0,0,0.45)', marginTop: 9, fontSize: 12, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 8, writingDirection: 'rtl' },
  searchRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  searchButton: { marginTop: 20, width: 45, height: 45, borderRadius: 14, justifyContent: 'center', alignItems: 'center' },
  results: { paddingVertical: 2, gap: 0 },
  resultRow: { minHeight: 58, flexDirection: 'row', alignItems: 'center', gap: 8, borderBottomWidth: StyleSheet.hairlineWidth, paddingVertical: 8 },
  productName: { fontSize: 13, fontWeight: '700', writingDirection: 'rtl', textAlign: 'right' },
  productMeta: { marginTop: 3, fontSize: 11, writingDirection: 'rtl', textAlign: 'right' },
  cartHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 1 },
  cartTitle: { fontSize: 17, fontWeight: '700', writingDirection: 'rtl' },
  cartCount: { fontSize: 12, writingDirection: 'rtl' },
  cartList: { gap: 8, paddingBottom: 4 },
  cartEmpty: { flexGrow: 1, justifyContent: 'center' },
  emptyCart: { alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 17 },
  emptyCartIcon: { width: 50, height: 50, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
  emptyTitle: { fontSize: 15, fontWeight: '700', writingDirection: 'rtl' },
  emptyNote: { fontSize: 12, textAlign: 'center', writingDirection: 'rtl' },
  cartItem: { minHeight: 72, paddingHorizontal: 11, paddingVertical: 8, borderWidth: 1, borderRadius: 17, flexDirection: 'row', alignItems: 'center', gap: 9, flexWrap: 'wrap' },
  lineTotal: { fontSize: 12, fontWeight: '700', writingDirection: 'rtl' },
  removeButton: { padding: 5 },
  stepper: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  stepButton: { width: 27, height: 27, borderRadius: 9, alignItems: 'center', justifyContent: 'center' },
  quantity: { minWidth: 13, textAlign: 'center', fontSize: 13, fontWeight: '700' },
  footer: { padding: 13, gap: 9, marginTop: 2 },
  payRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  payLabel: { fontSize: 12, writingDirection: 'rtl' },
  paymentOptions: { flexDirection: 'row', gap: 7 },
  paymentOption: { minWidth: 58, paddingHorizontal: 10, paddingVertical: 6, borderRadius: 10, alignItems: 'center' },
  totalRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  totalLabel: { fontSize: 12, writingDirection: 'rtl' },
  totalValue: { fontSize: 13, fontWeight: '600', writingDirection: 'rtl' },
  discountRow: { flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between', gap: 8 },
  totalRight: { flex: 1, alignItems: 'flex-end', paddingBottom: 3, gap: 2 },
  grandTotal: { fontSize: 20, fontWeight: '800', writingDirection: 'rtl' },
});
