import React from 'react';
import { Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import { AppPage, Card, PageHeader } from '@/components/common';
import { useStore } from '@/components/StoreContext';
import { useColors } from '@/hooks/useColors';

const options = [
  { title: 'المشتريات', description: 'إدخال فواتير الموردين', icon: 'truck', route: '/purchases' },
  { title: 'المرتجعات', description: 'إرجاع المنتجات المباعة إلى المخزون', icon: 'corner-up-left', route: '/returns' },
  { title: 'جرد المخزون', description: 'مقارنة الكمية الفعلية بالمسجلة', icon: 'check-square', route: '/inventory-count' },
  { title: 'الفواتير المصورة', description: 'إرفاق صورة الفاتورة ومراجعة بنودها', icon: 'camera', route: '/invoice' },
  { title: 'Excel', description: 'استيراد وتصدير قائمة المنتجات', icon: 'file-text', route: '/excel' },
  { title: 'سجل العمليات', description: 'مراجعة تغييرات البيع والمخزون', icon: 'activity', route: '/audit' },
] as const;

export default function MoreScreen() {
  const colors = useColors();
  const { currentUser, logout } = useStore();
  const signOut = () => Alert.alert('تسجيل الخروج', 'هل تريد إنهاء الجلسة الحالية؟', [
    { text: 'إلغاء', style: 'cancel' },
    { text: 'خروج', style: 'destructive', onPress: () => { logout(); router.replace('/login' as never); } },
  ]);
  return (
    <AppPage>
      <PageHeader title="المزيد" subtitle="إدارة المتجر والأدوات" />
      <Card style={styles.profile}>
        <View style={[styles.profileIcon, { backgroundColor: colors.secondary }]}><Feather name="user" size={21} color={colors.primary} /></View>
        <View style={styles.profileText}>
          <Text style={[styles.profileName, { color: colors.foreground }]}>{currentUser?.name}</Text>
          <Text style={[styles.profileRole, { color: colors.mutedForeground }]}>{currentUser?.role === 'owner' ? 'مالك المتجر' : 'موظف'}</Text>
        </View>
        <Pressable accessibilityRole="button" accessibilityLabel="تغيير رمز PIN" onPress={() => router.push('/change-pin' as never)} style={styles.pinButton}>
          <Feather name="key" size={17} color={colors.primary} />
        </Pressable>
      </Card>
      <View style={styles.options}>
        {options.map((option) => (
          <Pressable key={option.route} accessibilityRole="button" onPress={() => router.push(option.route as never)} style={({ pressed }) => [styles.option, { backgroundColor: colors.card, borderColor: colors.border, opacity: pressed ? 0.76 : 1 }]}>
            <View style={[styles.optionIcon, { backgroundColor: colors.secondary }]}><Feather name={option.icon} size={19} color={colors.primary} /></View>
            <View style={styles.optionText}>
              <Text style={[styles.optionTitle, { color: colors.foreground }]}>{option.title}</Text>
              <Text style={[styles.optionDescription, { color: colors.mutedForeground }]}>{option.description}</Text>
            </View>
            <Feather name="chevron-left" size={19} color={colors.mutedForeground} />
          </Pressable>
        ))}
        {currentUser?.role === 'owner' ? (
          <Pressable accessibilityRole="button" onPress={() => router.push('/employees' as never)} style={({ pressed }) => [styles.option, { backgroundColor: colors.card, borderColor: colors.border, opacity: pressed ? 0.76 : 1 }]}>
            <View style={[styles.optionIcon, { backgroundColor: colors.secondary }]}><Feather name="users" size={19} color={colors.primary} /></View>
            <View style={styles.optionText}>
              <Text style={[styles.optionTitle, { color: colors.foreground }]}>الموظفون والصلاحيات</Text>
              <Text style={[styles.optionDescription, { color: colors.mutedForeground }]}>إضافة المستخدمين وإيقافهم</Text>
            </View>
            <Feather name="chevron-left" size={19} color={colors.mutedForeground} />
          </Pressable>
        ) : null}
      </View>
      <Pressable accessibilityRole="button" onPress={signOut} style={[styles.logout, { borderColor: colors.border }]}>
        <Feather name="log-out" size={18} color={colors.destructive} />
        <Text style={[styles.logoutText, { color: colors.destructive }]}>تسجيل الخروج</Text>
      </Pressable>
      <Text style={[styles.version, { color: colors.mutedForeground }]}>مخزني POS · نسخة تجريبية · بيانات محلية على هذا الجهاز</Text>
    </AppPage>
  );
}

const styles = StyleSheet.create({
  profile: { flexDirection: 'row', alignItems: 'center', gap: 11, padding: 14 },
  profileIcon: { width: 43, height: 43, borderRadius: 15, justifyContent: 'center', alignItems: 'center' },
  profileText: { flex: 1, gap: 4, alignItems: 'flex-start' },
  profileName: { fontSize: 15, fontWeight: '700', writingDirection: 'rtl' },
  profileRole: { fontSize: 11, writingDirection: 'rtl' },
  pinButton: { width: 38, height: 38, alignItems: 'center', justifyContent: 'center' },
  options: { gap: 9 },
  option: { minHeight: 70, borderWidth: 1, borderRadius: 19, paddingHorizontal: 13, flexDirection: 'row', alignItems: 'center', gap: 11 },
  optionIcon: { width: 39, height: 39, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  optionText: { flex: 1, gap: 4, alignItems: 'flex-start' },
  optionTitle: { fontSize: 14, fontWeight: '700', writingDirection: 'rtl' },
  optionDescription: { fontSize: 10, writingDirection: 'rtl' },
  logout: { minHeight: 49, borderRadius: 16, borderWidth: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 9, marginTop: 2 },
  logoutText: { fontSize: 13, fontWeight: '700', writingDirection: 'rtl' },
  version: { textAlign: 'center', fontSize: 10, writingDirection: 'rtl' },
});
