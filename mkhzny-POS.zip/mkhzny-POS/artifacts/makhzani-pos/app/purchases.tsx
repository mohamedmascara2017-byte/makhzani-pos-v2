import React from 'react';
import PurchaseComposer from '@/components/PurchaseComposer';

export default function PurchasesScreen() {
  return <PurchaseComposer />;
}
