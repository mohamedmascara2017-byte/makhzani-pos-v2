مخزني V8.1 - Windows

هذا الأرشيف يحتوي على مجلد mkhzny-POS الخاص بالمشروع.
ارفع ملف ZIP إلى جذر مستودع GitHub، ثم أنشئ ملف GitHub Actions من الكود المرفق بشكل منفصل داخل:
.github/workflows/windows-v8_1-build.yml

بعد نجاح Actions، حمّل Artifact باسم Makhzani-POS-V8.1-Windows-Setup، فك ضغطه، ثم شغّل ملف Setup.exe.

ملاحظة: يلزم تشغيل GitHub Actions بنجاح لإنتاج ملف التثبيت. لم يتم تنفيذ بناء Windows فعلي في بيئة إعداد هذا الأرشيف.
