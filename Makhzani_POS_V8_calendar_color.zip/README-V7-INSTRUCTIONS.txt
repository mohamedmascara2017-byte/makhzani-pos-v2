MAKHZANI POS V7 - WINDOWS BUILD BUNDLE

Archive layout:
- mkhzny-POS/: existing Makhzani POS source workspace
- .github/workflows/windows-v7-build.yml: GitHub Actions workflow

Recommended setup:
1. Extract this ZIP on your computer.
2. Upload the extracted CONTENTS to the ROOT of your GitHub repository, preserving both mkhzny-POS and .github folders.
3. Confirm that the workflow is at .github/workflows/windows-v7-build.yml.
4. Open GitHub Actions and run Makhzani POS V7 - Windows Installer.

Alternatively, upload this ZIP to the repository root and create .github/workflows/windows-v7-build.yml separately using the standalone YAML file. The workflow can extract this exact ZIP automatically.

This V7 bundle improves Windows build workflow, installer discovery, and diagnostics. It does not rewrite or independently validate the application's sales, inventory, backup, or database logic.
