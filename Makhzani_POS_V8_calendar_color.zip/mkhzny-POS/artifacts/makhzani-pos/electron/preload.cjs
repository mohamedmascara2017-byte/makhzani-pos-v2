const { contextBridge } = require('electron');
contextBridge.exposeInMainWorld('makhzaniDesktop', {
  isDesktop: true,
  platform: process.platform,
});
