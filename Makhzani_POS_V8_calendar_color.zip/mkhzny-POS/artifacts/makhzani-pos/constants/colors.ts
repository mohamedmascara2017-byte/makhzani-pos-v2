/**
 * Makhzani modern retail palette: deep navy + emerald teal.
 * Shared semantic tokens keep the entire POS experience consistent.
 */
const colors = {
  light: {
    text: '#202044',
    tint: '#625BFF',
    background: '#F5F6FF',
    foreground: '#202044',
    card: '#FFFFFF',
    cardForeground: '#202044',
    primary: '#625BFF',
    primaryForeground: '#FFFFFF',
    secondary: '#ECEBFF',
    secondaryForeground: '#4942C8',
    muted: '#EEF0FA',
    mutedForeground: '#777A96',
    accent: '#FFB547',
    accentForeground: '#49300A',
    destructive: '#E6536D',
    destructiveForeground: '#FFFFFF',
    border: '#E3E5F3',
    input: '#D9DCEF',
  },
  dark: {
    text: '#F2F1FF',
    tint: '#A49FFF',
    background: '#111226',
    foreground: '#F2F1FF',
    card: '#1D1E38',
    cardForeground: '#F2F1FF',
    primary: '#8B84FF',
    primaryForeground: '#17162F',
    secondary: '#302F55',
    secondaryForeground: '#D4D1FF',
    muted: '#282944',
    mutedForeground: '#AAAAC8',
    accent: '#FFC36A',
    accentForeground: '#49300A',
    destructive: '#FF7189',
    destructiveForeground: '#FFFFFF',
    border: '#3B3C60',
    input: '#45466B',
  },
  radius: 18,
};

export default colors;
