/**
 * Makhzani modern retail palette: deep navy + emerald teal.
 * Shared semantic tokens keep the entire POS experience consistent.
 */
const colors = {
  light: {
    text: '#17243A',
    tint: '#0F9F8F',
    background: '#F3F6FA',
    foreground: '#17243A',
    card: '#FFFFFF',
    cardForeground: '#17243A',
    primary: '#0F9F8F',
    primaryForeground: '#FFFFFF',
    secondary: '#E7F3F2',
    secondaryForeground: '#08796F',
    muted: '#EDF1F6',
    mutedForeground: '#718096',
    accent: '#F4B942',
    accentForeground: '#392A08',
    destructive: '#D94B5B',
    destructiveForeground: '#FFFFFF',
    border: '#E2E8F0',
    input: '#D8E1EB',
  },
  dark: {
    text: '#EAF0F8',
    tint: '#39C6B5',
    background: '#111827',
    foreground: '#EAF0F8',
    card: '#1B2638',
    cardForeground: '#EAF0F8',
    primary: '#39C6B5',
    primaryForeground: '#092A2A',
    secondary: '#24384A',
    secondaryForeground: '#B9F1E9',
    muted: '#243044',
    mutedForeground: '#A2B0C3',
    accent: '#F4B942',
    accentForeground: '#392A08',
    destructive: '#F07883',
    destructiveForeground: '#FFFFFF',
    border: '#334155',
    input: '#3B4B61',
  },
  radius: 18,
};

export default colors;
